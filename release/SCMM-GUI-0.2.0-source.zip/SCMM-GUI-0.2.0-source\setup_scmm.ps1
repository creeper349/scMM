$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$projectRoot = $PSScriptRoot
$environmentPath = Join-Path $projectRoot ".scmm-env"
$environmentPython = Join-Path $environmentPath "python.exe"
$runtimeRoot = Join-Path $env:LOCALAPPDATA "SCMM\Miniconda3"
$setupCache = Join-Path $projectRoot ".setup-cache"
$installer = Join-Path $setupCache "Miniconda3-latest-Windows-x86_64.exe"
Set-Location -LiteralPath $projectRoot

function Find-Conda {
    $command = Get-Command conda.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    foreach ($candidate in @(
        (Join-Path $runtimeRoot "Scripts\conda.exe"),
        (Join-Path $env:USERPROFILE "miniconda3\Scripts\conda.exe"),
        (Join-Path $env:USERPROFILE "anaconda3\Scripts\conda.exe"),
        "C:\ProgramData\Miniconda3\Scripts\conda.exe",
        "C:\ProgramData\Anaconda3\Scripts\conda.exe"
    )) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return $null
}

Write-Host "[SCMM] Checking Conda..." -ForegroundColor Cyan
$conda = Find-Conda
if (-not $conda) {
    Write-Host "[SCMM] Conda was not found; installing official Miniconda for this user."
    New-Item -ItemType Directory -Force -Path $setupCache | Out-Null
    if (-not (Test-Path -LiteralPath $installer)) {
        Invoke-WebRequest `
            -Uri "https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe" `
            -OutFile $installer
    }
    $signature = Get-AuthenticodeSignature -LiteralPath $installer
    if ($signature.Status -ne "Valid") {
        throw "The downloaded Miniconda installer does not have a valid signature."
    }
    $process = Start-Process -FilePath $installer -Wait -PassThru -WindowStyle Hidden `
        -ArgumentList @("/InstallationType=JustMe", "/RegisterPython=0", "/AddToPath=0", "/S", "/D=$runtimeRoot")
    if ($process.ExitCode -ne 0) {
        throw "Miniconda installation failed with exit code $($process.ExitCode)."
    }
    $conda = Join-Path $runtimeRoot "Scripts\conda.exe"
}

if (Test-Path -LiteralPath $environmentPython) {
    Write-Host "[SCMM] Updating the local environment..." -ForegroundColor Cyan
    & $conda env update --prefix $environmentPath --file (Join-Path $projectRoot "environment.yml") --prune
} else {
    Write-Host "[SCMM] Creating the local environment..." -ForegroundColor Cyan
    & $conda env create --prefix $environmentPath --file (Join-Path $projectRoot "environment.yml")
}
if ($LASTEXITCODE -ne 0) { throw "Conda environment configuration failed." }

& $environmentPython -m pip install --upgrade --editable "$projectRoot[ml,web]"
if ($LASTEXITCODE -ne 0) { throw "SCMM package installation failed." }

# Force official PyPI wheels. The Conda igraph build loads an MKL runtime that
# can make threadpoolctl fail before otherwise unrelated sklearn algorithms.
& $environmentPython -m pip install --upgrade --force-reinstall --only-binary=:all: `
    "igraph==1.0.0" "leidenalg==0.12.0"
if ($LASTEXITCODE -ne 0) { throw "SCMM graph dependency repair failed." }

Write-Host ""
Write-Host "[SCMM] Environment is ready." -ForegroundColor Green
Write-Host "Start with: .\start_scmm.cmd"
