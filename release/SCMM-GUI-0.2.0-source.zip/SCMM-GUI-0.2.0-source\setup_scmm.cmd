@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_scmm.ps1"
if errorlevel 1 (
  echo.
  echo SCMM environment setup failed. Review the message above.
  pause
  exit /b 1
)
echo.
echo SCMM environment setup completed.
pause
