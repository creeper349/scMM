from __future__ import annotations

import io
import json
import os
import re
import subprocess
import sys
import tempfile
import traceback
import zipfile
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd


_BUILTIN_UI_CONFIG = Path(__file__).with_name("config") / "defaults.json"


@lru_cache(maxsize=1)
def _ui_config():
    """Load UI defaults/help, optionally from ``SCMM_UI_CONFIG``."""
    configured = os.environ.get("SCMM_UI_CONFIG")
    path = Path(configured).expanduser() if configured else _BUILTIN_UI_CONFIG
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        if configured:
            raise RuntimeError(f"无法读取 UI 配置 {path}: {exc}") from exc
        return {"parameters": {}}


def _parameter(parameter_id, fallback, fallback_help=""):
    entry = _ui_config().get("parameters", {}).get(parameter_id, {})
    return entry.get("default", fallback), entry.get("help", fallback_help)


def _choice(parameter_id, options, fallback_index=0):
    options = list(options)
    fallback = options[fallback_index]
    value, help_text = _parameter(parameter_id, fallback)
    index = options.index(value) if value in options else fallback_index
    return index, help_text


def _bounded_default(parameter_id, fallback, lower, upper):
    value, help_text = _parameter(parameter_id, fallback)
    return min(upper, max(lower, value)), help_text


def _dense(matrix):
    return matrix.toarray() if hasattr(matrix, "toarray") else np.asarray(matrix)


def _now():
    return datetime.now().strftime("%H:%M:%S")


def _substep_from_message(message):
    """Extract a stable substep label and its local progress from a report."""
    text = str(message).strip()
    match = re.search(r"(?P<current>\d+)\s*/\s*(?P<total>\d+)", text)
    local_progress = None
    if match:
        current = int(match.group("current"))
        total = max(1, int(match.group("total")))
        local_progress = min(100, max(0, round(current / total * 100)))
        label = (text[: match.start()] + text[match.end() :]).strip(" :-|")
        label = re.sub(
            r"\b(files?|frames?|blocks?)\b",
            "",
            label,
            flags=re.IGNORECASE,
        ).strip(" :-|")
    else:
        label = text.split(":", 1)[0].strip() if ":" in text else text
    return label or "Processing", local_progress


def _state(st):
    input_default, _ = _parameter("data.input_path", "")
    preview_default, _ = _parameter("preview.file", "")
    defaults = {
        "data": None,
        "logs": [f"[{_now()}] SCMM web workbench ready"],
        "tasks": [],
        "result_table": pd.DataFrame(),
        "supervised": None,
        "network": None,
        "differential_result": pd.DataFrame(),
        "differential_context": None,
        "preview_chrom": None,
        "preview_spectrum": None,
        "preview_cells": None,
        "input_path": input_default,
        "preview_path": preview_default,
        "completed_steps": set(),
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


class Terminal:
    """Persistent task terminal with one progress record per operation."""

    def __init__(self, st, progress_slot, report_slot, output_slot):
        self.st = st
        self.progress_slot = progress_slot
        self.report_slot = report_slot
        self.output_slot = output_slot
        self.current = None
        self.render()

    def render(self):
        tasks = self.st.session_state.tasks
        running = next(
            (task for task in reversed(tasks) if task["status"] == "running"),
            None,
        )
        if running is None:
            self.progress_slot.empty()
            self.report_slot.empty()
        else:
            self.progress_slot.progress(
                int(running["progress"]),
                text=(
                    f"⏳ {running['step']} · {running['progress']}% · "
                    f"{running['message']}"
                ),
            )
            active = next(
                (
                    step
                    for step in reversed(running.get("substeps", []))
                    if step["status"] == "running"
                ),
                None,
            )
            if active is None:
                self.report_slot.empty()
            else:
                self.report_slot.progress(
                    int(active["progress"]),
                    text=f"当前步骤：{active['label']} · {active['progress']}%",
                )
        self.output_slot.code(
            "\n".join(self.st.session_state.logs[-80:]),
            language=None,
            height=320,
        )

    def start(self, title):
        task = {
            "step": title,
            "status": "running",
            "progress": 0,
            "message": "Starting",
            "started": _now(),
            "substeps": [],
        }
        self.st.session_state.tasks.append(task)
        self.current = len(self.st.session_state.tasks) - 1
        self.write(f"START | {title}")
        self.progress_slot.progress(0, text=title)

    def update(self, fraction, message):
        percent = min(100, max(0, int(float(fraction) * 100)))
        if self.current is not None:
            task = self.st.session_state.tasks[self.current]
            task["progress"] = percent
            task["message"] = str(message)
            label, local_progress = _substep_from_message(message)
            substeps = task.setdefault("substeps", [])
            if not substeps or substeps[-1]["label"] != label:
                if substeps and substeps[-1]["status"] == "running":
                    substeps[-1]["progress"] = 100
                    substeps[-1]["status"] = "completed"
                substeps.append(
                    {
                        "label": label,
                        "progress": local_progress if local_progress is not None else 5,
                        "status": "running",
                    }
                )
            else:
                substeps[-1]["progress"] = (
                    local_progress
                    if local_progress is not None
                    else max(substeps[-1]["progress"], percent)
                )
        self.progress_slot.progress(percent, text=str(message))
        self.write(f"{percent:3d}% | {message}")

    def write(self, message):
        self.st.session_state.logs.append(f"[{_now()}] {message}")
        self.render()

    def finish(self, message):
        if self.current is not None:
            task = self.st.session_state.tasks[self.current]
            task["progress"] = 100
            task["message"] = str(message)
            task["status"] = "completed"
            for substep in task.get("substeps", []):
                substep["progress"] = 100
                substep["status"] = "completed"
        self.progress_slot.progress(100, text=str(message))
        self.write(f"100% | {message}")
        self.render()

    def fail(self, exc):
        if self.current is not None:
            task = self.st.session_state.tasks[self.current]
            task["status"] = "failed"
            task["message"] = str(exc)
            if task.get("substeps"):
                task["substeps"][-1]["status"] = "failed"
        self.write(f"ERROR | {type(exc).__name__}: {exc}")
        self.write(traceback.format_exc().strip())
        self.progress_slot.error(str(exc))


def _terminal(st):
    st.markdown("#### 实时任务终端")
    progress_slot = st.empty()
    report_slot = st.empty()
    output_slot = st.empty()
    return Terminal(st, progress_slot, report_slot, output_slot)


def _execute(st, terminal, title, function, completed_step=None):
    terminal.start(title)
    try:
        result = function(terminal.update)
    except Exception as exc:
        terminal.fail(exc)
        st.error(f"{title}失败：{exc}")
        return None
    terminal.finish(f"{title}完成")
    if completed_step:
        st.session_state.completed_steps.add(completed_step)
    return result


def _pipeline_status(st):
    steps = [
        ("data", "数据"),
        ("preprocess", "预处理"),
        ("embedding", "降维"),
        ("cluster", "聚类"),
        ("trajectory", "轨迹"),
        ("analysis", "统计/模型"),
    ]
    columns = st.columns(len(steps))
    done = st.session_state.completed_steps
    for column, (key, label) in zip(columns, steps):
        column.markdown(f"{'✅' if key in done else '○'} **{label}**")


def _engine(st):
    from scMM.plot.engine import PlotEngine

    return PlotEngine.from_adata(st.session_state.data, copy=False)


def _browse(st, kind, state_key):
    from scMM.file.dialogs import choose_local_path

    try:
        selected = choose_local_path(kind)
    except Exception as exc:
        st.error(f"无法打开本机选择器：{exc}")
        return
    if selected:
        st.session_state[state_key] = selected


def _h5ad_bytes(data):
    with tempfile.NamedTemporaryFile(suffix=".h5ad", delete=False) as handle:
        path = Path(handle.name)
    try:
        data.save(path)
        return path.read_bytes()
    finally:
        path.unlink(missing_ok=True)


def _csv_zip(data):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("X.csv", data.to_df().to_csv())
        archive.writestr("obs.csv", data.obs.to_csv())
        archive.writestr("var.csv", data.var.to_csv())
    return buffer.getvalue()


def _plot_embedding(
    st,
    data,
    key,
    color_mode,
    color_key,
    feature,
    cmap,
    categorical_palette,
):
    import plotly.express as px

    values = np.asarray(data.obsm[key])
    if values.shape[1] < 2:
        st.warning("该嵌入只有一个维度，无法绘制二维图。")
        return
    frame = pd.DataFrame(
        {"dimension 1": values[:, 0], "dimension 2": values[:, 1]},
        index=data.obs_names,
    )
    color = None
    if color_mode == "obs":
        color = color_key
        frame[color] = data.obs[color_key].to_numpy()
    elif color_mode == "feature":
        color = f"intensity: {feature}"
        frame[color] = _dense(data[:, feature].X).ravel()
    figure = px.scatter(
        frame,
        x="dimension 1",
        y="dimension 2",
        color=color,
        hover_name=frame.index,
        render_mode="webgl",
        color_continuous_scale=cmap,
        color_discrete_sequence=getattr(
            px.colors.qualitative,
            categorical_palette,
        ),
    )
    figure.update_layout(height=650, margin=dict(l=10, r=10, t=30, b=10))
    st.plotly_chart(figure, use_container_width=True)


def page_data():
    import streamlit as st

    from scMM.file.data import CyESIData
    from scMM.workflows import ProcessingConfig, parse_reference_mz, run_processing

    st.header("数据导入与 CyESI 峰提取")
    st.caption("选择一种明确的输入模式；本机选择按钮打开运行 SCMM 的电脑上的原生对话框。")
    _pipeline_status(st)
    terminal = _terminal(st)

    modes = {
        "加载已有 H5AD": "h5ad",
        "处理单个 mzML / mzXML / RAW 文件": "single",
        "批量目录：统一质量轴（先累加所有文件，再用共同 m/z 特征提取）": "shared",
        "批量目录：独立质量轴（每个文件单独寻峰，再按 ppm 合并并保留特有峰）": "independent",
    }
    mode_index, mode_help = _choice("data.input_mode", list(modes))
    label = st.radio("输入模式", list(modes), index=mode_index, help=mode_help)
    mode = modes[label]
    choose_kind = "directory" if mode in {"shared", "independent"} else "file"
    if st.button("📁 选择文件夹" if choose_kind == "directory" else "📄 选择文件"):
        _browse(st, choose_kind, "input_path")
    input_path = st.text_input("已选择路径", key="input_path", help=_parameter("data.input_path", "")[1])

    if mode == "h5ad":
        uploaded = st.file_uploader("也可以从浏览器上传 H5AD", type=["h5ad"], help=_parameter("data.upload_h5ad", None)[1])

        def load_h5ad(progress):
            progress(0.15, "Reading H5AD")
            if uploaded is not None:
                with tempfile.NamedTemporaryFile(suffix=".h5ad", delete=False) as handle:
                    handle.write(uploaded.getbuffer())
                    temporary = Path(handle.name)
                try:
                    result = CyESIData.read(temporary)
                finally:
                    temporary.unlink(missing_ok=True)
            else:
                if not input_path:
                    raise ValueError("请选择 H5AD 文件")
                result = CyESIData.read(input_path)
            progress(0.9, f"Loaded {result.n_obs} cells × {result.n_vars} features")
            return result

        if st.button("加载 H5AD", type="primary", use_container_width=True):
            result = _execute(st, terminal, "加载 H5AD", load_h5ad, "data")
            if result is not None:
                st.session_state.data = result
                st.rerun()
        return

    st.subheader("Reference 与输出")
    c1, c2 = st.columns(2)
    reference_default, reference_help = _parameter("data.reference_mz", "734.5929")
    reference_text = c1.text_input("Reference m/z（逗号分隔）", value=str(reference_default), key="extraction_reference", help=reference_help)
    reference_index, reference_mode_help = _choice("data.reference_mode", ["union", "intersection"])
    reference_mode = c2.radio("多个 reference 的细胞判定", ["union", "intersection"], index=reference_index, horizontal=True, help=reference_mode_help)
    output_default, output_help = _parameter("data.output_path", "results/scmm_result.h5ad")
    output_default = Path(output_default)
    if not output_default.is_absolute(): output_default = Path.cwd() / output_default
    output_path = st.text_input("H5AD 输出路径", value=str(output_default), help=output_help)
    c1, c2 = st.columns(2)
    metadata_default, metadata_help = _parameter("data.metadata_path", "")
    metadata = c1.text_input("样本元数据 CSV（可选）", value=str(metadata_default), help=metadata_help)
    msconvert_default, msconvert_help = _parameter("data.msconvert", "")
    msconvert = c2.text_input("msconvert.exe（RAW 可选）", value=str(msconvert_default), help=msconvert_help)
    frame_default, frame_help = _parameter("data.frame_metadata", ["rt"])
    frame_metadata = st.multiselect("写入 obs 的帧元数据", ["rt", "ms_level", "native_id"], default=frame_default, help=frame_help)
    st.caption("原始 frame_id 会强制写入 obs，不受此选项影响；MS2 及更高等级谱不会进入细胞提取。")

    st.subheader("质量轴与峰参数")
    a, b = st.columns(2)
    value, help_text = _parameter("data.mz_min", 100.0); processing_mz_min = a.number_input("处理 m/z 下限", 0.000001, 100000.0, float(value), help=help_text)
    value, help_text = _parameter("data.mz_max", 1000.0); processing_mz_max = b.number_input("处理 m/z 上限", 0.000001, 100000.0, float(value), help=help_text)
    a, b, c = st.columns(3)
    value, help_text = _parameter("data.ppm", 10.0); ppm = a.number_input("特征匹配 ppm", 0.01, 1000.0, float(value), help=help_text)
    value, help_text = _parameter("data.merge_ppm", 10.0); merge_ppm = b.number_input("文件间合并 ppm", 0.01, 1000.0, float(value), disabled=mode != "independent", help=help_text)
    value, help_text = _parameter("data.resolution", 35000.0); resolution = c.number_input("分辨率 @ m/z 200", 100.0, 2_000_000.0, float(value), help=help_text)
    value, help_text = _parameter("data.resample_points", 5.0); points = a.number_input("每 FWHM 重采样点", 1.0, 50.0, float(value), help=help_text)
    value, help_text = _parameter("data.spectrum_snr", 10.0); spectrum_snr = b.number_input("总谱峰 SNR", 0.0, 1000.0, float(value), help=help_text)
    value, help_text = _parameter("data.prominence", 0.0); prominence = c.number_input("峰 prominence ratio（0=自动）", 0.0, 1.0, float(value), help=help_text)
    value, help_text = _parameter("data.peak_distance", 3); distance = a.number_input("峰最小点距", 1, 1000, int(value), help=help_text)
    value, help_text = _parameter("data.block_size", 256); block = b.number_input("Feature block size", 1, 100000, int(value), help=help_text)
    value, help_text = _parameter("data.create_qc", True); create_qc = c.checkbox("生成 QC PDF", value=bool(value), help=help_text)

    st.subheader("细胞与特征判定")
    a, b, c = st.columns(3)
    value, help_text = _parameter("data.cell_threshold", 5.0); cell_threshold = a.number_input("Reference/基线阈值", 0.0, 100000.0, float(value), help=help_text)
    value, help_text = _parameter("data.feature_snr", 3.0); feature_snr = b.number_input("Feature SNR 阈值", 0.0, 1000.0, float(value), help=help_text)
    value, help_text = _parameter("data.max_zero", 0.9); max_zero = c.number_input("特征最大零比例", 0.0, 1.0, float(value), help=help_text)
    value, help_text = _parameter("data.baseline_window", 51); baseline = a.number_input("基线滑窗", 3, 10001, int(value), step=2, help=help_text)
    value, help_text = _parameter("data.noise_window", 51); noise = b.number_input("噪声滑窗", 3, 10001, int(value), step=2, help=help_text)

    def process(progress):
        if not input_path:
            raise ValueError("请选择输入文件或目录")
        config = ProcessingConfig(
            input_path=input_path,
            output_path=output_path,
            reference_mz=parse_reference_mz(reference_text),
            reference_mode=reference_mode,
            feature_strategy="independent" if mode == "independent" else "shared",
            feature_merge_ppm=merge_ppm,
            ppm_tol=ppm,
            mz_min=processing_mz_min,
            mz_max=processing_mz_max,
            resolution=resolution,
            resample_points_per_fwhm=points,
            ms_peak_snr_threshold=spectrum_snr,
            prominence_ratio=None if prominence == 0 else prominence,
            peak_distance=distance,
            cell_threshold=cell_threshold,
            feature_snr=feature_snr,
            baseline_window=baseline,
            noise_window=noise,
            max_zero_fraction=max_zero,
            feature_block_size=block,
            metadata_path=metadata,
            frame_metadata=tuple(frame_metadata),
            create_qc=create_qc,
            msconvert_path=msconvert,
        )
        return run_processing(config, progress_callback=progress)

    if st.button("开始峰提取", type="primary", use_container_width=True):
        result = _execute(st, terminal, "CyESI 峰提取", process, "data")
        if result is not None:
            st.session_state.data = result[0]
            st.rerun()


def _preview_source(st):
    if st.button("📄 选择用于预览的质谱文件"):
        _browse(st, "file", "preview_path")
    current = Path(st.session_state.get("input_path", ""))
    if current.is_dir():
        files = sorted(
            str(path) for path in current.iterdir()
            if path.suffix.lower() in {".mzml", ".mzxml", ".raw"}
        )
        if files:
            configured, help_text = _parameter("preview.directory_file", "")
            selected_index = files.index(configured) if configured in files else 0
            selected = st.selectbox("从当前输入目录选择", files, index=selected_index, help=help_text)
            if not st.session_state.preview_path:
                st.session_state.preview_path = selected
    return st.text_input("预览文件", key="preview_path", help=_parameter("preview.file", "")[1])


def page_preview():
    import plotly.express as px
    import plotly.graph_objects as go
    import streamlit as st

    from scMM.analysis import cell_detection_preview, chromatogram_preview, spectrum_preview
    from scMM.workflows import parse_reference_mz

    st.header("原始信号交互预览")
    st.caption("查看 TIC、EIC、任意 MS1 扫描的质谱，以及与正式算法一致的细胞提取结果。")
    terminal = _terminal(st)
    path = _preview_source(st)
    c1, c2 = st.columns(2)
    value, help_text = _parameter("preview.msconvert", ""); msconvert = c1.text_input("msconvert.exe（RAW 可选）", value=str(value), key="preview_msconvert", help=help_text)
    value, help_text = _parameter("preview.ppm", 10.0); ppm = c2.number_input("EIC ppm", 0.01, 1000.0, float(value), help=help_text)

    tic_tab, spectrum_tab, cell_tab, processed_tab = st.tabs(
        ["TIC / EIC", "MS1 质谱", "细胞提取预览", "处理后叠加谱 / 特征"]
    )
    with tic_tab:
        preview_ref_default, preview_ref_help = _parameter("preview.eic_mz", st.session_state.get("extraction_reference", "734.5929"))
        references = st.text_input(
            "EIC m/z（逗号分隔）",
            value=str(preview_ref_default),
            key="preview_references",
            help=preview_ref_help,
        )
        if st.button("读取 TIC / EIC", type="primary"):
            result = _execute(
                st,
                terminal,
                "读取 TIC/EIC",
                lambda progress: chromatogram_preview(
                    path,
                    parse_reference_mz(references),
                    ppm=ppm,
                    msconvert_path=msconvert or None,
                    progress_callback=progress,
                ),
            )
            if result is not None:
                st.session_state.preview_chrom = result[0]
                st.rerun()
        frame = st.session_state.preview_chrom
        if frame is not None and not frame.empty:
            frame = frame.copy()
            frame["cell_frame"] = False
            data = st.session_state.data
            if data is not None and {"source_file", "frame_id"} <= set(data.obs.columns):
                source_name = Path(path).name
                source_stem = Path(path).stem
                source_mask = data.obs["source_file"].astype(str).map(
                    lambda value: (
                        value.casefold() == source_name.casefold()
                        or Path(value).stem.casefold() == source_stem.casefold()
                    )
                )
                cell_frames = set(
                    data.obs.loc[source_mask, "frame_id"].dropna().astype(int)
                )
                frame["cell_frame"] = frame["frame_id"].isin(cell_frames)
                st.caption(
                    f"已从当前结果标记 {int(frame['cell_frame'].sum())} 个细胞帧"
                    f"（源文件：{source_name}）。"
                )
            x_index, x_help = _choice("preview.x_axis", ["rt", "scan"])
            x_axis = st.radio("横轴", ["rt", "scan"], index=x_index, horizontal=True, help=x_help)
            trace_default, trace_help = _parameter("preview.traces", [])
            trace_options = [
                column for column in frame
                if column not in {"rt", "scan", "frame_id", "cell_frame"}
            ]
            trace_default = [item for item in trace_default if item in trace_options] or trace_options
            traces = st.multiselect(
                "显示曲线", trace_options, default=trace_default, help=trace_help
            )
            long = frame.melt(
                id_vars=["frame_id", "scan", "rt", "cell_frame"],
                value_vars=traces,
                var_name="trace",
                value_name="intensity",
            )
            figure = px.line(
                long,
                x=x_axis,
                y="intensity",
                color="trace",
                render_mode="webgl",
                hover_data=["frame_id"],
            )
            marked = long[long["cell_frame"]]
            if not marked.empty:
                figure.add_scatter(
                    x=marked[x_axis],
                    y=marked["intensity"],
                    mode="markers",
                    marker=dict(size=8, symbol="x", color="black"),
                    text=marked["frame_id"],
                    hovertemplate="cell frame=%{text}<br>intensity=%{y:.6g}<extra></extra>",
                    name="cell frames",
                )
            figure.update_layout(height=600)
            st.plotly_chart(figure, use_container_width=True)
    with spectrum_tab:
        value, help_text = _parameter("preview.scan", 0); scan = st.number_input("MS1 scan 序号", 0, 10_000_000, int(value), help=help_text)
        a, b = st.columns(2)
        value, help_text = _parameter("preview.mz_min", 100.0); mz_min = a.number_input("m/z 下限", 0.0, 100000.0, float(value), help=help_text)
        value, help_text = _parameter("preview.mz_max", 1000.0); mz_max = b.number_input("m/z 上限", 0.0, 100000.0, float(value), help=help_text)
        value, help_text = _parameter("preview.max_points", 10000); max_points = st.number_input("最大绘图点数（按 m/z 顺序采样）", 100, 100000, int(value), help=help_text)
        value, help_text = _parameter("preview.line_color", "#1f77b4"); line_color = st.color_picker("谱线颜色", str(value), help=help_text)
        if st.button("读取质谱"):
            result = _execute(
                st,
                terminal,
                "读取 MS1 质谱",
                lambda progress: (
                    progress(0.2, "Loading raw-MS file"),
                    spectrum_preview(path, scan, msconvert_path=msconvert or None),
                )[1],
            )
            if result is not None:
                st.session_state.preview_spectrum = result
                st.rerun()
        result = st.session_state.preview_spectrum
        if result is not None:
            frame, rt, count, _ = result
            subset = frame[frame["mz"].between(mz_min, mz_max)]
            if len(subset) > max_points:
                selected = np.linspace(0, len(subset) - 1, max_points, dtype=int)
                subset = subset.iloc[np.unique(selected)]
            figure = go.Figure(
                go.Scattergl(
                    x=subset["mz"],
                    y=subset["intensity"],
                    mode="lines",
                    line=dict(width=1, color=line_color),
                    hovertemplate="m/z=%{x:.6f}<br>Intensity=%{y:.6g}<extra></extra>",
                )
            )
            figure.update_layout(title=f"MS1 scan {scan}/{count - 1}, RT={rt:g}", xaxis_title="m/z", yaxis_title="Intensity", height=600)
            st.plotly_chart(figure, use_container_width=True)
    with cell_tab:
        value, help_text = _parameter("preview.cell_reference", st.session_state.get("extraction_reference", "734.5929")); references = st.text_input("Reference m/z", value=str(value), key="cell_preview_refs", help=help_text)
        a, b, c = st.columns(3)
        index, help_text = _choice("preview.reference_mode", ["union", "intersection"]); ref_mode = a.selectbox("Reference 组合", ["union", "intersection"], index=index, key="cell_preview_mode", help=help_text)
        value, help_text = _parameter("preview.cell_threshold", 5.0); threshold = b.number_input("Reference/基线阈值", 0.0, 10000.0, float(value), key="cell_preview_threshold", help=help_text)
        value, help_text = _parameter("preview.feature_snr", 3.0); feature_snr = c.number_input("Feature SNR", 0.0, 1000.0, float(value), key="cell_preview_snr", help=help_text)
        value, help_text = _parameter("preview.baseline_window", 51); baseline = a.number_input("基线窗口", 3, 10001, int(value), step=2, key="cell_preview_baseline", help=help_text)
        value, help_text = _parameter("preview.noise_window", 51); noise = b.number_input("噪声窗口", 3, 10001, int(value), step=2, key="cell_preview_noise", help=help_text)
        value, help_text = _parameter("preview.resolution", 35000.0); resolution = c.number_input("分辨率", 100.0, 2_000_000.0, float(value), key="cell_preview_resolution", help=help_text)
        d, e = st.columns(2)
        value, help_text = _parameter("preview.processing_mz_min", 100.0); cell_mz_min = d.number_input("预览处理 m/z 下限", 0.000001, 100000.0, float(value), key="cell_preview_mz_min", help=help_text)
        value, help_text = _parameter("preview.processing_mz_max", 1000.0); cell_mz_max = e.number_input("预览处理 m/z 上限", 0.000001, 100000.0, float(value), key="cell_preview_mz_max", help=help_text)
        if st.button("运行细胞提取预览", type="primary"):
            result = _execute(
                st,
                terminal,
                "细胞提取预览",
                lambda progress: cell_detection_preview(
                    path,
                    parse_reference_mz(references),
                    reference_mode=ref_mode,
                    msconvert_path=msconvert or None,
                    progress_callback=progress,
                    ppm_tol=ppm,
                    mz_range=(cell_mz_min, cell_mz_max),
                    resolution=resolution,
                    cell_signal_threshold=threshold,
                    feature_snr_threshold=feature_snr,
                    baseline_window=baseline,
                    noise_window=noise,
                ),
            )
            if result is not None:
                st.session_state.preview_cells = result[0]
                st.rerun()
        frame = st.session_state.preview_cells
        if frame is not None:
            signals = [column for column in frame if column.startswith("m/z ")]
            long = frame.reset_index().melt(id_vars=["x", "cell_window", "cell_apex"], value_vars=signals, var_name="reference", value_name="intensity")
            figure = px.line(long, x="x", y="intensity", color="reference", render_mode="webgl")
            apex = long[long["cell_apex"]]
            figure.add_scatter(x=apex["x"], y=apex["intensity"], mode="markers", marker=dict(size=9, symbol="x", color="black"), name="cell apex")
            figure.update_layout(height=620, xaxis_title="RT / frame")
            st.plotly_chart(figure, use_container_width=True)
    with processed_tab:
        data = st.session_state.data
        spectra = {} if data is None else data.uns.get("summed_spectra", {})
        if not spectra:
            st.info("当前数据不含叠加谱。请先使用新版程序完成峰提取；旧 H5AD 不会自动补充原始叠加谱。")
        else:
            names = list(spectra)
            configured, help_text = _parameter("preview.processed_spectrum", "")
            selected_name = st.selectbox(
                "叠加谱来源",
                names,
                index=names.index(configured) if configured in names else 0,
                help=help_text,
            )
            payload = spectra[selected_name]
            summed_mz = np.asarray(payload["mz"], dtype=float)
            summed_intensity = np.asarray(payload["intensity"], dtype=float)
            value, help_text = _bounded_default(
                "preview.summed_max_points", 30000, 1000, 200000
            )
            max_points = st.number_input(
                "叠加谱最大绘图点数", 1000, 200000, int(value), help=help_text
            )
            if len(summed_mz) > max_points:
                selected_indices = np.unique(
                    np.linspace(0, len(summed_mz) - 1, max_points, dtype=int)
                )
                plot_mz = summed_mz[selected_indices]
                plot_intensity = summed_intensity[selected_indices]
            else:
                plot_mz, plot_intensity = summed_mz, summed_intensity
            figure = go.Figure()
            figure.add_scatter(
                x=plot_mz,
                y=plot_intensity,
                mode="lines",
                line=dict(width=1, color="#4c78a8"),
                name="summed MS1 spectrum",
            )
            a, b = st.columns(2)
            value, help_text = _parameter("preview.show_candidates", False)
            show_candidates = a.checkbox("标记候选峰", bool(value), help=help_text)
            value, help_text = _parameter("preview.show_retained", True)
            show_retained = b.checkbox("标记最终保留特征", bool(value), help=help_text)
            marker_sets = []
            if show_candidates:
                marker_sets.append(("candidate peaks", payload.get("candidate_mz", []), "#f2a900", "circle-open"))
            if show_retained:
                marker_sets.append(("retained features", payload.get("retained_feature_mz", data.var["mz"]), "#d62728", "x"))
            for label, marker_mz, color, symbol in marker_sets:
                marker_mz = np.asarray(marker_mz, dtype=float)
                if marker_mz.size:
                    figure.add_scatter(
                        x=marker_mz,
                        y=np.interp(marker_mz, summed_mz, summed_intensity),
                        mode="markers",
                        marker=dict(size=8, color=color, symbol=symbol),
                        name=label,
                        hovertemplate="m/z=%{x:.6f}<br>intensity=%{y:.6g}<extra></extra>",
                    )
            figure.update_layout(
                height=650,
                title=f"处理后叠加 MS1 谱：{selected_name}",
                xaxis_title="m/z",
                yaxis_title="Summed intensity",
            )
            st.plotly_chart(figure, use_container_width=True)
            st.subheader(f"最终特征表（{data.n_vars} 个）")
            feature_table = data.var.copy()
            feature_table.insert(0, "feature_id", data.var_names.astype(str))
            st.dataframe(feature_table, use_container_width=True, height=420, hide_index=True)


def page_preprocess():
    import plotly.express as px
    import streamlit as st

    from scMM.analysis import quality_metrics

    st.header("归一化、插补与质量控制")
    _pipeline_status(st)
    terminal = _terminal(st)
    data = st.session_state.data
    if data is None:
        st.warning("请先在“数据导入”页面加载或处理数据。")
        return
    st.subheader("归一化")
    options = ["total", "max", "quantile", "pqn", "zscore", "log", "minmax"]
    index, help_text = _choice("preprocess.normalize_method", options); method = st.selectbox("方法", options, index=index, help=help_text)
    a, b, c = st.columns(3)
    value, help_text = _parameter("preprocess.total_scale", 1.0); scale = a.number_input("Total scale", value=float(value), format="%.6g", help=help_text)
    index, help_text = _choice("preprocess.axis", [0, 1]); axis = b.selectbox("Axis", [0, 1], index=index, help=help_text)
    value, help_text = _parameter("preprocess.log_pseudo", 1e-6); pseudo = c.number_input("Log pseudo", value=float(value), format="%.8g", help=help_text)
    index, help_text = _choice("preprocess.pqn_reference", ["median", "mean"]); pqn_reference = a.selectbox("PQN reference", ["median", "mean"], index=index, help=help_text)
    if st.button("应用归一化", type="primary"):
        params = {"total": {"scale": scale}, "zscore": {"axis": axis}, "minmax": {"axis": axis}, "log": {"pseudo": pseudo}, "pqn": {"reference": pqn_reference}}.get(method, {})
        result = _execute(st, terminal, "归一化", lambda progress: (progress(0.15, "Preparing matrix"), data.normalize(method, **params), progress(0.9, "Updating AnnData"))[1], "preprocess")
        if result is not None: st.rerun()
    st.subheader("缺失值插补")
    options = ["knn", "mean", "median", "most_frequent", "constant"]
    index, help_text = _choice("preprocess.impute_method", options); method = st.selectbox("插补方法", options, index=index, help=help_text)
    a, b = st.columns(2)
    value, help_text = _parameter("preprocess.knn_neighbors", 5); neighbors = a.number_input("KNN 邻居", 1, 100, int(value), help=help_text)
    value, help_text = _parameter("preprocess.constant_fill", 0.0); fill = b.number_input("Constant 填充值", value=float(value), help=help_text)
    if st.button("应用插补"):
        kwargs = {"n_neighbors": neighbors} if method == "knn" else ({"fill_value": fill} if method == "constant" else {})
        result = _execute(st, terminal, "缺失值插补", lambda progress: (progress(0.1, "Fitting imputer"), data.impute(method, **kwargs), progress(0.9, "Writing imputed matrix"))[1], "preprocess")
        if result is not None: st.rerun()
    st.subheader("异常细胞")
    value, help_text = _parameter("preprocess.outlier_contamination", 0.05); contamination = st.number_input("Isolation Forest contamination", 0.001, 0.5, float(value), help=help_text)
    if st.button("检测并移除异常细胞"):
        before = data.n_obs
        result = _execute(st, terminal, "异常细胞检测", lambda progress: (progress(0.15, "Fitting Isolation Forest"), data.remove_outlier(contamination=contamination, random_state=42), progress(0.9, "Subsetting observations"))[1], "preprocess")
        if result is not None:
            terminal.write(f"Removed {before - data.n_obs} cells")
            st.rerun()
    st.subheader("交互式 QC")
    metrics = quality_metrics(data)["cell"]
    metric_options = [column for column in metrics if pd.api.types.is_numeric_dtype(metrics[column])]
    configured, help_text = _parameter("preprocess.qc_metric", "")
    metric = st.selectbox("指标", metric_options, index=metric_options.index(configured) if configured in metric_options else 0, help=help_text)
    color = "source_file" if "source_file" in metrics else None
    figure = px.histogram(metrics, x=metric, color=color, marginal="box", opacity=0.65)
    figure.update_layout(height=560)
    st.plotly_chart(figure, use_container_width=True)


def page_discovery():
    import streamlit as st

    st.header("降维、聚类与轨迹分析")
    _pipeline_status(st)
    terminal = _terminal(st)
    data = st.session_state.data
    if data is None:
        st.warning("请先加载数据。")
        return
    reduction_tab, cluster_tab, trajectory_tab, plot_tab = st.tabs(["降维", "聚类", "轨迹", "嵌入图"])
    with reduction_tab:
        method_options = ["pca", "umap", "tsne", "isomap", "lle"]
        index, help_text = _choice("discovery.reduction_method", method_options); method = st.selectbox("降维方法", method_options, index=index, help=help_text)
        reps = ["原始 X", *data.obsm.keys()]
        configured, help_text = _parameter("discovery.reduction_rep", "原始 X")
        fallback_index = 0 if method == "pca" else (reps.index("X_pca") if "X_pca" in reps else 0)
        use_rep_label = st.selectbox("输入表示", reps, index=reps.index(configured) if configured in reps else fallback_index, help=help_text)
        use_rep = None if use_rep_label == "原始 X" else use_rep_label
        a, b, c = st.columns(3)
        value, help_text = _parameter("discovery.components", 2); components = a.number_input("输出维数", 1, 100, int(value), help=help_text)
        value, help_text = _parameter("discovery.scale", True); scale = b.checkbox("标准化输入", bool(value), help=help_text)
        value, help_text = _parameter("discovery.seed", 42); seed = c.number_input("随机种子", 0, 2_147_483_647, int(value), help=help_text)
        params = {}
        if method == "umap":
            upper = max(2, data.n_obs - 1); value, help_text = _bounded_default("discovery.neighbors", min(30, upper), 2, upper); params["n_neighbors"] = a.number_input("n_neighbors", 2, upper, int(value), help=help_text)
            value, help_text = _parameter("discovery.umap_min_dist", 0.3); params["min_dist"] = b.number_input("min_dist", 0.0, 1.0, float(value), help=help_text)
            options = ["euclidean", "cosine", "correlation", "manhattan"]; index, help_text = _choice("discovery.metric", options); params["metric"] = c.selectbox("metric", options, index=index, help=help_text)
        elif method == "tsne":
            upper = float(max(2, data.n_obs - 1)); value, help_text = _bounded_default("discovery.tsne_perplexity", min(30.0, upper), 1.0, upper); params["perplexity"] = a.number_input("perplexity", 1.0, upper, float(value), help=help_text)
            value, help_text = _parameter("discovery.tsne_exaggeration", 12.0); params["early_exaggeration"] = b.number_input("early_exaggeration", 1.0, 100.0, float(value), help=help_text)
            value, help_text = _parameter("discovery.tsne_learning_rate", 200.0); params["learning_rate"] = c.number_input("learning_rate", 1.0, 10000.0, float(value), help=help_text)
            options = ["pca", "random"]; index, help_text = _choice("discovery.tsne_init", options); params["init"] = a.selectbox("init", options, index=index, help=help_text)
            options = ["euclidean", "cosine", "correlation", "manhattan"]; index, help_text = _choice("discovery.metric", options); params["metric"] = b.selectbox("t-SNE metric", options, index=index, help=help_text)
            value, help_text = _parameter("discovery.tsne_iterations", 1000); params["max_iter"] = c.number_input("max_iter", 250, 10000, int(value), help=help_text)
        elif method == "isomap":
            upper = max(2, data.n_obs - 1); value, help_text = _bounded_default("discovery.neighbors", min(15, upper), 2, upper); params["n_neighbors"] = a.number_input("n_neighbors", 2, upper, int(value), key="isomap_neighbors", help=help_text)
            options = ["euclidean", "manhattan", "cosine"]; index, help_text = _choice("discovery.metric", options); params["metric"] = b.selectbox("Isomap metric", options, index=index, help=help_text)
            options = ["auto", "FW", "D"]; index, help_text = _choice("discovery.isomap_path", options); params["path_method"] = c.selectbox("path_method", options, index=index, help=help_text)
        elif method == "lle":
            upper = max(2, data.n_obs - 1); value, help_text = _bounded_default("discovery.neighbors", min(15, upper), 2, upper); params["n_neighbors"] = a.number_input("n_neighbors", 2, upper, int(value), key="lle_neighbors", help=help_text)
            options = ["standard", "modified", "hessian", "ltsa"]; index, help_text = _choice("discovery.lle_method", options); params["method"] = b.selectbox("LLE method", options, index=index, help=help_text)
            options = ["auto", "arpack", "dense"]; index, help_text = _choice("discovery.eigen_solver", options); params["eigen_solver"] = c.selectbox("eigen_solver", options, index=index, help=help_text)
        configured, help_text = _parameter("discovery.store_key", ""); store_key = st.text_input("写入 obsm 的键", value=str(configured or f"X_{method}"), key=f"store_{method}", help=help_text)
        if st.button("运行降维", type="primary"):
            result = _execute(
                st,
                terminal,
                f"{method.upper()} 降维",
                lambda progress: (
                    progress(0.1, "Preparing representation"),
                    _engine(st).reduce_dimension(method, use_rep=use_rep, n_components=components, scale=scale, random_state=seed, store_key=store_key, **params),
                    progress(0.92, f"Writing obsm[{store_key!r}]"),
                )[1],
                "embedding",
            )
            if result is not None: st.rerun()
    with cluster_tab:
        options = ["leiden", "louvain", "kmeans", "agglomerative", "dbscan"]; index, help_text = _choice("discovery.cluster_method", options); method = st.selectbox("聚类算法", options, index=index, help=help_text)
        rep_options = ["原始 X", *data.obsm.keys()]; index, help_text = _choice("discovery.cluster_rep", rep_options); representation = st.selectbox("聚类输入", rep_options, index=index, key="cluster_rep", help=help_text)
        configured, help_text = _parameter("discovery.cluster_key", ""); key_added = st.text_input("写入 obs 的标签列名", value=str(configured or f"{method}_cluster"), help=help_text)
        a, b, c = st.columns(3)
        value, help_text = _parameter("discovery.cluster_count", 4); cluster_count = a.number_input("聚类数", 2, 200, int(value), help=help_text)
        upper = max(2, data.n_obs - 1); value, help_text = _bounded_default("discovery.graph_neighbors", min(15, upper), 2, upper); graph_neighbors = b.number_input("图邻居数", 2, upper, int(value), help=help_text)
        value, help_text = _parameter("discovery.resolution", 1.0); resolution = c.number_input("Leiden/Louvain resolution", 0.01, 20.0, float(value), help=help_text)
        value, help_text = _parameter("discovery.dbscan_eps", 0.5); eps = a.number_input("DBSCAN eps", 0.001, 100.0, float(value), help=help_text)
        value, help_text = _parameter("discovery.dbscan_min_samples", 5); min_samples = b.number_input("DBSCAN min_samples", 1, 1000, int(value), help=help_text)
        value, help_text = _parameter("discovery.cluster_seed", 42); seed = c.number_input("聚类随机种子", 0, 2_147_483_647, int(value), help=help_text)
        if st.button("运行聚类并写入 obs", type="primary"):
            kwargs = ({"n_clusters": cluster_count} if method in {"kmeans", "agglomerative"} else ({"eps": eps, "min_samples": min_samples} if method == "dbscan" else {"n_neighbors": graph_neighbors, "resolution": resolution}))
            use_rep = None if representation == "原始 X" else representation
            result = _execute(st, terminal, f"{method} 聚类", lambda progress: (progress(0.1, "Preparing graph / matrix"), _engine(st).cluster_cells(method, use_rep=use_rep, key_added=key_added, random_state=seed, **kwargs), progress(0.9, f"Writing obs[{key_added!r}]"))[1], "cluster")
            if result is not None:
                terminal.write(f"Generated {result.nunique()} clusters in obs[{key_added!r}]")
                st.rerun()
    with trajectory_tab:
        methods = {
            "Diffusion pseudotime (DPT)": "diffusion_pseudotime",
            "kNN graph geodesic pseudotime": "graph_pseudotime",
            "PCA pseudotime": "pca_pseudotime",
            "PAGA-like cluster graph pseudotime": "paga_pseudotime",
        }
        method_options = list(methods); index, help_text = _choice("discovery.trajectory_method", method_options); method_label = st.selectbox("轨迹方法", method_options, index=index, help=help_text)
        method = methods[method_label]
        rep_options = ["原始 X", *data.obsm.keys()]; index, help_text = _choice("discovery.trajectory_rep", rep_options); representation = st.selectbox("轨迹输入", rep_options, index=index, key="trajectory_rep", help=help_text)
        configured, help_text = _parameter("discovery.pseudotime_key", ""); key_added = st.text_input("写入 obs 的伪时间列", value=str(configured or f"{method}_value"), help=help_text)
        a, b, c = st.columns(3)
        upper = max(2, data.n_obs - 1); value, help_text = _bounded_default("discovery.trajectory_neighbors", min(15, upper), 2, upper); neighbors = a.number_input("轨迹图邻居数", 2, upper, int(value), help=help_text)
        value, help_text = _parameter("discovery.diffusion_components", 10); components = b.number_input("Diffusion components", 1, 50, int(value), help=help_text)
        cluster_columns = [column for column in data.obs if not pd.api.types.is_numeric_dtype(data.obs[column])]
        cluster_options = cluster_columns or data.obs.columns.tolist(); configured, help_text = _parameter("discovery.paga_cluster_key", ""); cluster_key = c.selectbox("PAGA 聚类列", cluster_options, index=cluster_options.index(configured) if configured in cluster_options else 0, help=help_text)
        root_options = ["第一细胞", "指定 cell ID", "按 obs 分组选代表细胞"]; index, help_text = _choice("discovery.root_mode", root_options); root_mode = st.radio("根细胞定义", root_options, index=index, horizontal=True, help=help_text)
        root_cell = None; root_obs = None; root_value = None
        if root_mode == "指定 cell ID":
            options = data.obs_names.astype(str).tolist(); configured, help_text = _parameter("discovery.root_cell", ""); root_cell = st.selectbox("Root cell", options, index=options.index(configured) if configured in options else 0, help=help_text)
        elif root_mode == "按 obs 分组选代表细胞":
            options = data.obs.columns.astype(str).tolist(); configured, help_text = _parameter("discovery.root_obs", ""); root_obs = st.selectbox("Root obs", options, index=options.index(configured) if configured in options else 0, help=help_text)
            options = sorted(data.obs[root_obs].dropna().astype(str).unique()); configured, help_text = _parameter("discovery.root_value", ""); root_value = st.selectbox("Root value", options, index=options.index(configured) if configured in options else 0, help=help_text)
        if st.button("运行轨迹并写入 obs", type="primary"):
            use_rep = None if representation == "原始 X" else representation
            result = _execute(st, terminal, method_label, lambda progress: (progress(0.1, "Building trajectory graph"), _engine(st).trajectory(method, use_rep=use_rep, key_added=key_added, root_cell=root_cell, root_obs=root_obs, root_value=root_value, n_neighbors=neighbors, n_components=components, cluster_key=cluster_key), progress(0.92, f"Writing obs[{key_added!r}]"))[1], "trajectory")
            if result is not None:
                terminal.write(f"Pseudotime written to obs[{key_added!r}]")
                if method == "diffusion_pseudotime": terminal.write("Diffusion components written to obsm['X_diffmap']")
                st.rerun()
    with plot_tab:
        embeddings = list(data.obsm.keys())
        if not embeddings:
            st.info("请先运行降维。")
        else:
            configured, help_text = _parameter("discovery.embedding", ""); embedding = st.selectbox("嵌入", embeddings, index=embeddings.index(configured) if configured in embeddings else 0, help=help_text)
            options = ["none", "obs", "feature"]; index, help_text = _choice("discovery.color_mode", options); color_mode = st.radio("上色方式", options, index=index, horizontal=True, help=help_text)
            a, b = st.columns(2)
            cmap_options = ["Viridis", "Plasma", "Inferno", "Magma", "Cividis", "Turbo", "RdBu", "Spectral"]
            index, help_text = _choice("discovery.cmap", cmap_options)
            cmap = a.selectbox(
                "连续变量 cmap",
                cmap_options,
                index=index,
                help=help_text,
            )
            palette_options = ["Plotly", "D3", "G10", "Safe", "Dark24", "Alphabet"]
            index, help_text = _choice("discovery.palette", palette_options)
            categorical_palette = b.selectbox(
                "分类变量配色",
                palette_options,
                index=index,
                help=help_text,
            )
            color_key = None; feature = None
            if color_mode == "obs":
                options = data.obs.columns.astype(str).tolist(); configured, help_text = _parameter("discovery.color_obs", ""); color_key = st.selectbox("obs 项", options, index=options.index(configured) if configured in options else 0, help=help_text)
            elif color_mode == "feature":
                options = data.var_names.astype(str).tolist(); configured, help_text = _parameter("discovery.color_feature", ""); feature = st.selectbox("特征", options, index=options.index(configured) if configured in options else 0, help=help_text)
            _plot_embedding(
                st,
                data,
                embedding,
                color_mode,
                color_key,
                feature,
                cmap,
                categorical_palette,
            )


def _bh_adjust(p_values):
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    ranked = values[order] * len(values) / np.arange(1, len(values) + 1)
    adjusted[order] = np.minimum.accumulate(ranked[::-1])[::-1]
    return np.clip(adjusted, 0.0, 1.0)


def _render_differential_plots(st, data):
    import plotly.express as px
    from scipy import stats

    result = st.session_state.differential_result
    context = st.session_state.differential_context
    if result is None or result.empty or not context:
        return
    st.divider()
    st.subheader("差异代谢物可视化")
    a, b, c = st.columns(3)
    fdr_default, fdr_help = _parameter("analysis.diff_fdr", 0.05)
    fold_default, fold_help = _parameter("analysis.diff_log2fc", 1.0)
    labels_default, labels_help = _parameter("analysis.diff_label_count", 10)
    fdr_limit = a.number_input("FDR 阈值", 0.0, 1.0, float(fdr_default), help=fdr_help)
    fold_limit = b.number_input("|log2 FC| 阈值", 0.0, 100.0, float(fold_default), help=fold_help)
    label_count = c.number_input("标注显著特征数", 0, 100, int(labels_default), help=labels_help)
    volcano = result.copy()
    volcano["-log10(FDR)"] = -np.log10(volcano["fdr"].clip(lower=np.finfo(float).tiny))
    significant = (volcano["fdr"] <= fdr_limit) & (volcano["log2_fold_change"].abs() >= fold_limit)
    volcano["change"] = np.where(
        significant,
        np.where(volcano["log2_fold_change"] > 0, "A enriched", "B enriched"),
        "not significant",
    )
    volcano["label"] = ""
    labelled = volcano.loc[significant].nsmallest(int(label_count), "fdr").index
    volcano.loc[labelled, "label"] = volcano.loc[labelled, "feature_id"].astype(str)
    figure = px.scatter(
        volcano,
        x="log2_fold_change",
        y="-log10(FDR)",
        color="change",
        text="label",
        hover_data=["feature_id", "mz", "mean_a", "mean_b", "p_value", "fdr"],
        color_discrete_map={"A enriched": "#d62728", "B enriched": "#1f77b4", "not significant": "#a7a7a7"},
    )
    figure.add_vline(x=fold_limit, line_dash="dash", line_color="#666")
    figure.add_vline(x=-fold_limit, line_dash="dash", line_color="#666")
    if fdr_limit > 0:
        figure.add_hline(y=-np.log10(fdr_limit), line_dash="dash", line_color="#666")
    figure.update_traces(textposition="top center")
    figure.update_layout(height=620, title=f"火山图：{context['group_a']} vs {context['group_b']}")
    st.plotly_chart(figure, use_container_width=True)

    options = result["feature_id"].astype(str).tolist()
    selection_default, selection_help = _parameter("analysis.diff_features", [])
    selected_default = [value for value in selection_default if value in options] or options[: min(4, len(options))]
    selected = st.multiselect("用于分布图的代谢物", options, default=selected_default, help=selection_help)
    a, b, c, d = st.columns(4)
    plot_index, plot_help = _choice("analysis.diff_plot_type", ["小提琴图", "箱线图"])
    plot_type = a.selectbox("分布图类型", ["小提琴图", "箱线图"], index=plot_index, help=plot_help)
    points_default, points_help = _parameter("analysis.diff_show_points", True)
    show_points = b.checkbox("显示散点", bool(points_default), help=points_help)
    zeros_default, zeros_help = _parameter("analysis.diff_remove_zeros", False)
    remove_zeros = c.checkbox("删除零值", bool(zeros_default), help=zeros_help)
    test_index, test_help = _choice("analysis.diff_plot_test", ["mannwhitney", "welch"])
    plot_test = d.selectbox("图中统计检验", ["mannwhitney", "welch"], index=test_index, help=test_help)
    if not selected:
        return
    groups = data.obs[context["group_key"]].astype(str)
    keep = groups.isin([str(context["group_a"]), str(context["group_b"])]).to_numpy()
    indices = [data.var_names.get_loc(feature) for feature in selected]
    values = _dense(data.X)[keep][:, indices]
    wide = pd.DataFrame(values, columns=selected)
    wide["group"] = groups.to_numpy()[keep]
    long = wide.melt(id_vars="group", var_name="feature", value_name="intensity").dropna()
    if remove_zeros:
        long = long[long["intensity"] != 0]
    test_rows = []
    for feature in selected:
        left = long.loc[(long["feature"] == feature) & (long["group"] == str(context["group_a"])), "intensity"]
        right = long.loc[(long["feature"] == feature) & (long["group"] == str(context["group_b"])), "intensity"]
        if len(left) and len(right):
            if plot_test == "mannwhitney":
                statistic, p_value = stats.mannwhitneyu(left, right, alternative="two-sided")
            else:
                statistic, p_value = stats.ttest_ind(left, right, equal_var=False, nan_policy="omit")
        else:
            statistic, p_value = np.nan, np.nan
        test_rows.append({"feature": feature, "n_A": len(left), "n_B": len(right), "statistic": statistic, "p_value": p_value})
    test_frame = pd.DataFrame(test_rows)
    finite = test_frame["p_value"].notna()
    test_frame["fdr"] = np.nan
    if finite.any():
        test_frame.loc[finite, "fdr"] = _bh_adjust(test_frame.loc[finite, "p_value"])
    points = "all" if show_points else False
    if plot_type == "小提琴图":
        distribution = px.violin(long, x="group", y="intensity", color="group", facet_col="feature", facet_col_wrap=3, box=True, points=points)
    else:
        distribution = px.box(long, x="group", y="intensity", color="group", facet_col="feature", facet_col_wrap=3, points=points)
    distribution.update_yaxes(matches=None)
    distribution.update_layout(height=max(460, 300 * ((len(selected) + 2) // 3)), showlegend=False)
    st.plotly_chart(distribution, use_container_width=True)
    st.caption("统计检验针对当前图中数据重新计算；选择“删除零值”时样本量会随特征变化。")
    st.dataframe(test_frame, use_container_width=True, hide_index=True)


def _render_supervised_plots(st, analyzer):
    import plotly.express as px
    import plotly.graph_objects as go

    result = analyzer.result_
    qc = result["model_qc"]
    columns = st.columns(4)
    for column, (name, value) in zip(columns, [("R²", qc["r2"]), ("Q²", qc["q2"]), ("PR-AUC", qc["pr_auc_macro"]), ("Brier", qc["brier_macro"])]):
        column.metric(name, f"{value:.3f}")
    st.caption(qc["definition"])

    if str(analyzer.model_name_).lower() in {"lda", "plsda", "pls-da"}:
        key = "X_lda" if str(analyzer.model_name_).lower() == "lda" else "X_plsda"
        scores = np.asarray(analyzer.data.obsm[key])[analyzer.valid_mask]
        latent = pd.DataFrame({"component 1": scores[:, 0], "component 2": scores[:, 1], "class": analyzer.y, "cell": analyzer.obs_names.astype(str)})
        figure = px.scatter(latent, x="component 1", y="component 2", color="class", hover_name="cell", title=f"{analyzer.model_name_.upper()} 潜变量得分图")
        figure.update_layout(height=540)
        st.plotly_chart(figure, use_container_width=True)

    left, right = st.columns(2)
    pr_figure = go.Figure()
    for name, values in analyzer.precision_recall_curves().items():
        pr_figure.add_scatter(x=values["recall"], y=values["precision"], mode="lines", name=f"{name} (AP={values['average_precision']:.3f})")
    pr_figure.update_layout(title="Precision–Recall", xaxis_title="Recall", yaxis_title="Precision", height=470)
    left.plotly_chart(pr_figure, use_container_width=True)
    calibration_figure = go.Figure()
    calibration_figure.add_scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash"), name="ideal")
    for name, values in analyzer.calibration_curves().items():
        calibration_figure.add_scatter(x=values["mean_predicted_probability"], y=values["fraction_positive"], mode="lines+markers", name=name)
    calibration_figure.update_layout(title="校正曲线", xaxis_title="Mean predicted probability", yaxis_title="Fraction positive", height=470)
    right.plotly_chart(calibration_figure, use_container_width=True)
    confusion = px.imshow(result["confusion_matrix"], x=analyzer.classes_.astype(str), y=analyzer.classes_.astype(str), text_auto=True, labels={"x": "Predicted", "y": "True"}, title="混淆矩阵")
    confusion.update_layout(height=470)
    st.plotly_chart(confusion, use_container_width=True)


def page_analysis():
    import streamlit as st

    from scMM.analysis import SupervisedAnalyzer

    st.header("统计分析与监督学习")
    _pipeline_status(st)
    terminal = _terminal(st)
    data = st.session_state.data
    if data is None:
        st.warning("请先加载数据。")
        return
    stats_tab, network_tab, supervised_tab = st.tabs(["差异与 Marker", "相关网络", "监督学习 / SHAP"])
    with stats_tab:
        group_options = data.obs.columns.astype(str).tolist()
        group_index, group_help = _choice("analysis.group_key", group_options)
        group_key = st.selectbox("分组列", group_options, index=group_index, help=group_help)
        values = sorted(data.obs[group_key].dropna().astype(str).unique())
        a, b = st.columns(2)
        configured, help_text = _parameter("analysis.group_a", ""); group_a = a.selectbox("Group A", values, index=values.index(configured) if configured in values else 0, help=help_text)
        configured, help_text = _parameter("analysis.group_b", ""); group_b = b.selectbox("Group B", values, index=values.index(configured) if configured in values else min(1, len(values) - 1), help=help_text)
        test_index, test_help = _choice("analysis.diff_test", ["mannwhitney", "welch"])
        test = st.selectbox("检验", ["mannwhitney", "welch"], index=test_index, help=test_help)
        if st.button("差异分析（BH-FDR）", type="primary"):
            result = _execute(st, terminal, "差异分析", lambda progress: (progress(0.1, "Testing features"), _engine(st).differential_features(group_key, group_a, group_b, method=test), progress(0.92, "Applying BH-FDR"))[1], "analysis")
            if result is not None:
                st.session_state.result_table = result
                st.session_state.differential_result = result
                st.session_state.differential_context = {"group_key": group_key, "group_a": group_a, "group_b": group_b, "test": test}
                st.rerun()
        if st.button("聚类 Marker 分析"):
            result = _execute(st, terminal, "Marker 分析", lambda progress: (progress(0.1, "Comparing clusters"), _engine(st).marker_features(group_key, method=test), progress(0.92, "Combining marker tables"))[1], "analysis")
            if result is not None: st.session_state.result_table = result; st.rerun()
        _render_differential_plots(st, data)
    with network_tab:
        a, b = st.columns(2)
        threshold_default, threshold_help = _parameter("analysis.correlation_threshold", 0.7)
        threshold = a.number_input("|相关系数|阈值", 0.0, 1.0, float(threshold_default), help=threshold_help)
        top_default, top_help = _bounded_default("analysis.top_features", min(100, data.n_vars), 2, min(5000, data.n_vars))
        top_features = b.number_input("Top variable features", 2, min(5000, data.n_vars), int(top_default), help=top_help)
        method_index, method_help = _choice("analysis.correlation_method", ["pearson", "spearman", "kendall"])
        method = st.selectbox("相关方法", ["pearson", "spearman", "kendall"], index=method_index, help=method_help)
        if st.button("构建相关网络", type="primary"):
            result = _execute(st, terminal, "相关网络", lambda progress: (progress(0.1, "Computing correlation matrix"), _engine(st).feature_correlation_network(method=method, min_abs_correlation=threshold, top_features=top_features), progress(0.92, "Building network"))[1], "analysis")
            if result is not None: st.session_state.network = result; st.session_state.result_table = result[1]; st.rerun()
    with supervised_tab:
        label_options = data.obs.columns.astype(str).tolist()
        label_index, label_help = _choice("supervised.label", label_options)
        label = st.selectbox("标签列", label_options, index=label_index, help=label_help)
        model_index, model_help = _choice("supervised.model", ["logistic", "random_forest", "lda", "plsda"])
        model = st.selectbox("模型", ["logistic", "random_forest", "lda", "plsda"], index=model_index, help=model_help)
        a, b, c = st.columns(3)
        cv_default, cv_help = _parameter("supervised.cv", 5)
        cv = a.number_input("CV folds", 2, 20, int(cv_default), help=cv_help)
        split_default, split_help = _parameter("supervised.test_size", 0.2)
        test_size = b.number_input("测试集比例", 0.05, 0.5, float(split_default), help=split_help)
        smote_default, smote_help = _parameter("supervised.smote", False)
        smote = c.checkbox("SMOTE", bool(smote_default), help=smote_help)
        tree_default, tree_help = _parameter("supervised.rf_trees", 500)
        trees = a.number_input("RF trees", 10, 5000, int(tree_default), help=tree_help)
        seed_default, seed_help = _parameter("supervised.seed", 42)
        seed = b.number_input("随机种子", 0, 2_147_483_647, int(seed_default), help=seed_help)
        bins_default, bins_help = _parameter("supervised.calibration_bins", 10)
        calibration_bins = c.number_input("校正曲线分箱数", 2, 50, int(bins_default), help=bins_help)
        model_params = {}
        if model == "plsda":
            pls_default, pls_help = _parameter("supervised.pls_components", 2)
            model_params["n_components"] = a.number_input("PLS components", 1, min(100, data.n_vars), min(int(pls_default), data.n_vars), help=pls_help)
        elif model == "lda":
            solver_index, solver_help = _choice("supervised.lda_solver", ["svd", "lsqr", "eigen"])
            solver = a.selectbox("LDA solver", ["svd", "lsqr", "eigen"], index=solver_index, help=solver_help)
            model_params["solver"] = solver
            if solver in {"lsqr", "eigen"}:
                shrink_index, shrink_help = _choice("supervised.lda_shrinkage", ["none", "auto"])
                shrinkage = b.selectbox("LDA shrinkage", ["none", "auto"], index=shrink_index, help=shrink_help)
                model_params["shrinkage"] = None if shrinkage == "none" else shrinkage
        if st.button("训练、交叉验证并生成质控", type="primary"):
            def train(progress):
                progress(0.05, "Preparing labels and matrix")
                analyzer = SupervisedAnalyzer(data, label, random_state=seed)
                params = dict(model_params)
                if model == "random_forest": params["n_estimators"] = trees
                progress(0.2, "Cross-validation and fitting")
                result = analyzer.evaluate(model, cv=cv, test_size=test_size, smote=smote, model_params=params, calibration_bins=calibration_bins)
                if model in {"lda", "plsda"}:
                    key, columns = analyzer.store_latent_scores()
                    progress(0.82, f"Writing obsm[{key!r}] and obs[{', '.join(columns)}]")
                st.session_state.supervised = analyzer
                progress(0.92, "Generating QC, PR and calibration reports")
                test_metrics = pd.DataFrame([result["test_metrics"]], index=["holdout"])
                qc_metrics = pd.DataFrame([{key: value for key, value in result["model_qc"].items() if isinstance(value, (int, float))}], index=["model_qc"])
                return pd.concat([test_metrics, qc_metrics, pd.DataFrame(result["classification_report"]).T])
            result = _execute(st, terminal, "监督学习", train, "analysis")
            if result is not None: st.session_state.result_table = result; st.rerun()
        shap_default, shap_help = _parameter("supervised.shap_samples", 100)
        shap_samples = st.number_input("SHAP 最大样本数", 1, 1000, int(shap_default), help=shap_help)
        if st.button("计算 SHAP", disabled=st.session_state.supervised is None):
            result = _execute(st, terminal, "SHAP", lambda progress: (progress(0.1, "Selecting background and samples"), st.session_state.supervised.explain_shap(max_samples=shap_samples), progress(0.92, "Aggregating SHAP values"))[1], "analysis")
            if result is not None:
                values = np.asarray(result.values)
                values = np.mean(np.abs(values), axis=(0, 2)) if values.ndim == 3 else np.mean(np.abs(values), axis=0)
                st.session_state.result_table = pd.DataFrame({"feature": st.session_state.supervised.feature_names, "mean_abs_shap": values}).sort_values("mean_abs_shap", ascending=False)
                st.rerun()
        analyzer = st.session_state.supervised
        if analyzer is not None and hasattr(analyzer, "model_"):
            _render_supervised_plots(st, analyzer)


def page_results():
    import networkx as nx
    import plotly.graph_objects as go
    import streamlit as st

    st.header("结果表、报告与导出")
    data = st.session_state.data
    if data is None:
        st.warning("暂无数据。")
        return
    st.metric("Cells × features", f"{data.n_obs:,} × {data.n_vars:,}")
    options = ["X", "obs", "var"]; index, help_text = _choice("results.table", options); table_name = st.radio("AnnData 表", options, index=index, horizontal=True, help=help_text)
    frame = data.to_df() if table_name == "X" else getattr(data, table_name)
    st.dataframe(frame, use_container_width=True, height=520)
    st.subheader("分析结果")
    result = st.session_state.result_table
    if result is not None and not result.empty:
        st.dataframe(result, use_container_width=True, height=480)
        st.download_button("下载分析结果 CSV", result.to_csv(index=True).encode("utf-8-sig"), "scmm_analysis_result.csv", "text/csv")
    else:
        st.info("尚无统计或模型结果。")
    supervised = st.session_state.supervised
    if supervised is not None and hasattr(supervised, "model_"):
        figure = go.Figure()
        for name, values in supervised.roc_curves().items():
            figure.add_scatter(x=values["fpr"], y=values["tpr"], mode="lines", name=f"{name} (AUC={values['auc']:.3f})")
        figure.add_scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash"), name="random")
        figure.update_layout(title="ROC", xaxis_title="False positive rate", yaxis_title="True positive rate", height=500)
        st.plotly_chart(figure, use_container_width=True)
    network = st.session_state.network
    if network is not None:
        graph, _ = network
        positions = nx.spring_layout(graph, seed=42, weight="weight")
        ex, ey = [], []
        for left, right in graph.edges:
            ex += [positions[left][0], positions[right][0], None]; ey += [positions[left][1], positions[right][1], None]
        nodes = list(graph.nodes)
        figure = go.Figure([
            go.Scatter(x=ex, y=ey, mode="lines", line=dict(width=0.7, color="#999"), hoverinfo="skip"),
            go.Scatter(x=[positions[node][0] for node in nodes], y=[positions[node][1] for node in nodes], mode="markers", text=nodes, hovertext=nodes, marker=dict(size=8, color=[graph.degree(node) for node in nodes], colorscale="Viridis")),
        ])
        figure.update_layout(title="Feature correlation network", height=600, showlegend=False)
        st.plotly_chart(figure, use_container_width=True)
    st.subheader("导出完整数据")
    a, b = st.columns(2)
    a.download_button("下载 H5AD", _h5ad_bytes(data), "scmm_result.h5ad", "application/octet-stream", use_container_width=True)
    b.download_button("下载 X/obs/var CSV 包", _csv_zip(data), "scmm_tables.zip", "application/zip", use_container_width=True)


def page_terminal():
    import streamlit as st

    st.header("任务进度与运行报告")
    terminal = _terminal(st)
    a, b = st.columns(2)
    if a.button("清空终端日志"):
        st.session_state.logs = [f"[{_now()}] Terminal cleared"]
        st.rerun()
    if b.button("清空任务报告"):
        st.session_state.tasks = []
        st.rerun()
    terminal.render()


def render_app():
    import streamlit as st

    st.set_page_config(page_title="SCMM CyESI Workbench", page_icon="🧬", layout="wide")
    _state(st)
    pages = [
        st.Page(page_data, title="数据导入与峰提取", icon="📥", default=True),
        st.Page(page_preview, title="TIC / EIC / 质谱预览", icon="📈"),
        st.Page(page_preprocess, title="预处理与质量控制", icon="🧹"),
        st.Page(page_discovery, title="降维、聚类与轨迹", icon="🧭"),
        st.Page(page_analysis, title="统计与监督学习", icon="🧪"),
        st.Page(page_results, title="结果与导出", icon="📦"),
        st.Page(page_terminal, title="任务终端", icon="🖥️"),
    ]
    navigation = st.navigation(pages, position="sidebar", expanded=True)
    st.sidebar.markdown("**SCMM CyESI Workbench**")
    data = st.session_state.data
    if data is not None:
        st.sidebar.success(f"{data.n_obs:,} cells × {data.n_vars:,} features")
    navigation.run()


def main():
    target = str(Path(__file__).resolve())
    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        target,
        "--server.address=127.0.0.1",
        "--server.port=8501",
        "--browser.gatherUsageStats=false",
    ]
    raise SystemExit(subprocess.call(command))


if __name__ == "__main__":
    render_app()
