$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$condaPython = Join-Path $projectRoot ".scmm-env\python.exe"
$venvPython = Join-Path $projectRoot ".scmm-env\Scripts\python.exe"
$python = if (Test-Path -LiteralPath $condaPython) { $condaPython } elseif (Test-Path -LiteralPath $venvPython) { $venvPython } else { $null }
if (-not $python -or -not (Test-Path -LiteralPath $python)) {
    Write-Host "[SCMM] Local environment is missing; starting automatic setup." -ForegroundColor Yellow
    & (Join-Path $projectRoot "setup_scmm.ps1")
    $python = if (Test-Path -LiteralPath $condaPython) { $condaPython } elseif (Test-Path -LiteralPath $venvPython) { $venvPython } else { $null }
    if ($LASTEXITCODE -ne 0 -or -not $python) {
        throw "SCMM environment setup failed."
    }
}
Set-Location -LiteralPath $projectRoot
& $python -m streamlit run (Join-Path $projectRoot "scMM\webapp.py") `
    --server.address=127.0.0.1 `
    --server.port=8501 `
    --server.headless=false `
    --browser.gatherUsageStats=false
exit $LASTEXITCODE
