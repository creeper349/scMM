# SCMM

SCMM processes CyESI mass-spectrometry frames into a cell-by-metabolite
`AnnData` object. Version 0.2 uses H5AD as its native storage format and keeps
the source MS file for every detected cell. It accepts mzML/mzXML directly and
vendor RAW input through ProteoWizard MSConvert.

## 一键配置与启动（Windows）

```powershell
setup_scmm.cmd
start_scmm.cmd
```

`setup_scmm.cmd` 会自动查找 Conda；未安装时会下载并验证官方 Miniconda，
随后在项目目录创建隔离的 `.scmm-env` 并安装网页端、机器学习和质谱依赖。
`start_scmm.cmd` 启动本机 Web 服务并打开 `http://127.0.0.1:8501`。
无需管理员权限，也不需要安装或分发 EXE。更新依赖时再次运行配置脚本即可。

如需手动配置：

```powershell
conda env create --prefix .\.scmm-env -f environment.yml
.\.scmm-env\python.exe -m pip install -e ".[ml,web]"
```

对于厂商 RAW 文件，请安装 ProteoWizard，并将 `msconvert.exe` 加入 `PATH`、
设置 `SCMM_MSCONVERT`，或在网页参数中指定其路径。

## Python API

```python
from scMM import CyESIData

data = CyESIData.load_from_directory(
    "data/mzml",
    reference_mz=[734.5929, 760.6085],
    reference_mode="union",       # or "intersection"
    frame_metadata=["rt"],        # optional; time is never normalized
    metadata_by_file={
        "control_1.mzML": {"group": "control", "batch": "A"},
        "treated_1.mzML": {"group": "treated", "batch": "A"},
    },
    cell_signal_threshold=5.0,
    feature_snr_threshold=3.0,
    feature_strategy="shared",   # or "independent"
    # msconvert_path=r"C:\Program Files\ProteoWizard...\msconvert.exe",
)

data.normalize("total", scale=1.0)
data.save("results/experiment.h5ad")
data.export_csv("results/csv")
```

`data.X` is the baseline-corrected cell-by-feature intensity matrix,
`data.obs` contains cell/source metadata, `data.var` contains m/z metadata,
and raw-file/processing metadata is stored in `data.uns`.

## Command line

```powershell
scmm process data/mzml results/experiment.h5ad `
  --reference-mz 734.5929 760.6085 `
  --reference-mode union `
  --frame-metadata rt `
  --metadata sample_metadata.csv `
  --feature-strategy shared

# RAW input, when MSConvert is not already on PATH:
scmm process sample.raw results/sample.h5ad `
  --reference-mz 734.5929 `
  --msconvert "C:\Program Files\ProteoWizard\msconvert.exe"

scmm inspect results/experiment.h5ad
scmm qc results/experiment.h5ad results/qc.pdf
scmm export results/experiment.h5ad results/csv
```

The metadata CSV must contain `source_file`; every other column is copied to
the cells originating from that file.

## Web GUI 工作台

```powershell
start_scmm.cmd
```

网页工作台通过侧栏划分为数据导入、原始信号预览、预处理与质控、降维/聚类/轨迹、
统计建模、结果导出和任务终端等独立页面。文件和目录既可手动输入，也可使用本机原生
选择按钮。目录处理明确区分“所有文件统一质量轴”和“每个文件独立质量轴后按 ppm 合并”。

原始信号页面提供可缩放、悬停查询的 TIC、EIC、MS1 质谱和细胞提取预览图。降维支持
PCA、UMAP、t-SNE、Isomap 与 LLE，嵌入图可按任意 `obs` 项（包括聚类、文件来源、
伪时间）或任意特征强度上色。轨迹分析支持 diffusion pseudotime、kNN graph geodesic、
PCA pseudotime 和 PAGA-like cluster graph pseudotime；伪时间写入 `obs`，diffusion
components 写入 `obsm["X_diffmap"]`。每次任务都有独立实时进度和可追溯运行报告。

## Analysis

```python
from scMM.plot.engine import PlotEngine

engine = PlotEngine.from_adata(data, "results/figures")
engine.pca(n_components=30)
engine.umap()
engine.cluster_cells(
    method="leiden",
    n_neighbors=15,
    resolution=1.0,
    key_added="leiden_cluster",  # writes labels to data.obs
)
engine.reduce_dimension("tsne", use_rep="X_pca", perplexity=30)
engine.trajectory(
    "diffusion_pseudotime",
    use_rep="X_pca",
    key_added="dpt",
)
markers = engine.marker_features("cluster")
comparison = engine.differential_features("group", "treated", "control")
```

Current analysis support includes PCA, UMAP, t-SNE, Isomap and LLE;
KMeans, hierarchical, DBSCAN, Leiden and Louvain clustering; four pseudotime
methods; clustering quality metrics,
cluster-marker tests, two-group differential analysis with BH-FDR correction,
feature correlation networks, scatter/regression plots, and PDF QC reports.

Supervised analysis keeps SMOTE inside each training/CV pipeline to avoid
leakage and supports LDA, PLS-DA, logistic regression and random forests:

```python
from scMM.analysis import SupervisedAnalyzer

analysis = SupervisedAnalyzer(data, "group", random_state=42)
result = analysis.evaluate("random_forest", cv=5, smote=True)
analysis.plot_roc("results/roc.pdf")
analysis.explain_shap(max_samples=100)
analysis.plot_shap("results/shap.pdf")
```

Install the optional analysis dependencies with `pip install -e .[ml]`.

## Directory processing modes

- `shared`: sum spectra across all files, determine one shared feature axis,
  then extract each file sequentially with bounded memory.
- `independent`: sum and peak-pick each file independently, then merge features
  by ppm while retaining features unique to one file.
