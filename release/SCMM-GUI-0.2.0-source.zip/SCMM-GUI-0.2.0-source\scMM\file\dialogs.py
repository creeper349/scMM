from __future__ import annotations

import subprocess
import sys


def _windows_dialog(kind):
    if kind == "directory":
        body = (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "$dialog=New-Object System.Windows.Forms.FolderBrowserDialog; "
            "$dialog.Description='Select the folder containing mzML, mzXML, or RAW files'; "
            "if($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)"
            "{[Console]::Out.Write($dialog.SelectedPath)}"
        )
    else:
        body = (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "$dialog=New-Object System.Windows.Forms.OpenFileDialog; "
            "$dialog.Title='Select a mass-spectrometry or H5AD file'; "
            "$dialog.Filter='Supported files (*.mzML;*.mzXML;*.raw;*.h5ad)|*.mzML;*.mzXML;*.raw;*.h5ad|All files (*.*)|*.*'; "
            "if($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)"
            "{[Console]::Out.Write($dialog.FileName)}"
        )
    completed = subprocess.run(
        ["powershell.exe", "-NoLogo", "-NoProfile", "-STA", "-Command", body],
        capture_output=True,
        text=True,
        check=True,
    )
    return completed.stdout.strip()


def choose_local_path(kind="file"):
    """Open an OS-native chooser on the machine running the local web server."""
    if kind not in {"file", "directory"}:
        raise ValueError("kind must be 'file' or 'directory'")
    if sys.platform == "win32":
        return _windows_dialog(kind)
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()
    try:
        if kind == "directory":
            return filedialog.askdirectory()
        return filedialog.askopenfilename(
            filetypes=[
                ("Supported files", "*.mzML *.mzXML *.raw *.h5ad"),
                ("All files", "*.*"),
            ]
        )
    finally:
        root.destroy()
