param(
    [string]$Python = "python"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$projectRoot = $PSScriptRoot
$environmentPath = Join-Path $projectRoot ".scmm-env"
$environmentPython = Join-Path $environmentPath "Scripts\python.exe"
Set-Location -LiteralPath $projectRoot

Write-Host "[SCMM] Checking 64-bit Python 3.11..." -ForegroundColor Cyan
& $Python -c "import struct,sys; assert sys.version_info[:2] == (3,11), 'Python 3.11 is required'; assert struct.calcsize('P') == 8, '64-bit Python is required'; print(sys.version)"
if ($LASTEXITCODE -ne 0) {
    throw "Please install 64-bit Python 3.11 and ensure python.exe is available in PATH."
}

if (-not (Test-Path -LiteralPath $environmentPython)) {
    if (Test-Path -LiteralPath $environmentPath) {
        throw "The existing .scmm-env is not a Python venv. Rename or remove it before using this installer."
    }
    Write-Host "[SCMM] Creating the local virtual environment..." -ForegroundColor Cyan
    & $Python -m venv $environmentPath
    if ($LASTEXITCODE -ne 0) { throw "Virtual environment creation failed." }
}

Write-Host "[SCMM] Installing SCMM and GUI dependencies..." -ForegroundColor Cyan
& $environmentPython -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw "pip bootstrap failed." }
& $environmentPython -m pip install --upgrade --editable "$projectRoot[ml,web]"
if ($LASTEXITCODE -ne 0) { throw "SCMM dependency installation failed." }
& $environmentPython -m pip install --upgrade --force-reinstall --only-binary=:all: "igraph==1.0.0" "leidenalg==0.12.0"
if ($LASTEXITCODE -ne 0) { throw "SCMM graph dependency installation failed." }

Write-Host ""
Write-Host "[SCMM] Installation completed." -ForegroundColor Green
Write-Host "Double-click start_scmm.cmd to launch the GUI."
