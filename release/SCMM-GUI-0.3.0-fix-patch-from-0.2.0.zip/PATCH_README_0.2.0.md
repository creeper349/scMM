﻿# SCMM 0.2.0 → SCMM-GUI-0.3.0-fix

1. 关闭 SCMM 网页程序及启动终端。
2. 将本补丁完整解压到原 SCMM 软件目录，使 `apply_patch_0.2.0.cmd` 与原来的 `start_scmm.cmd` 同级。
3. 双击 `apply_patch_0.2.0.cmd`，等待程序更新和依赖检查完成。首次补齐依赖需要联网。
4. 运行 `start_scmm.cmd`。

旧程序和配置自动备份到 `.scmm-update-backups`。已有环境、数据及结果保留。升级采用新版默认参数，原来的自定义参数和语言包可从备份中合并。

如环境配置失败，保留窗口中的错误，处理后重新运行 `setup_scmm.cmd`。可稍后选择安装可选的 Thermo RAW 组件。补丁可重复运行。

Close SCMM, extract the entire patch into the existing software folder, and run `apply_patch_0.2.0.cmd`. It backs up the previous program, installs the complete updated source, and checks missing/incompatible dependencies. Internet access is needed for dependency installation. Then run `start_scmm.cmd`. Previous settings are in `.scmm-update-backups`.

完整说明见更新后的 `UPGRADE_TO_0.3.0-fix.md`。
