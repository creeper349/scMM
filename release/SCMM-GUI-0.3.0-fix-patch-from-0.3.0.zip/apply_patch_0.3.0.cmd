@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scmm_patch_0.3.0\apply_update.ps1" -Target "%~dp0." %*
set "SCMM_PATCH_EXIT=%errorlevel%"
echo.
if not "%SCMM_PATCH_EXIT%"=="0" echo [SCMM] Update failed with exit code %SCMM_PATCH_EXIT%. Review the error above.
pause
exit /b %SCMM_PATCH_EXIT%
